package com.yehia.album_media.api

import android.content.Context
import android.content.Intent
import com.yehia.album_media.Album
import com.yehia.album_media.AlbumFile
import com.yehia.album_media.app.gallery.GalleryAlbumActivity

class GalleryAlbumWrapper(context: Context) :
    BasicGalleryWrapper<GalleryAlbumWrapper, AlbumFile, String, AlbumFile>(context) {
    override fun start() {
        GalleryAlbumActivity.sResult = mResult
        GalleryAlbumActivity.sCancel = mCancel
        GalleryAlbumActivity.sClick = mItemClick
        GalleryAlbumActivity.sLongClick = mItemLongClick
        val intent = Intent(mContext, GalleryAlbumActivity::class.java)
        intent.putExtra(Album.KEY_INPUT_WIDGET, mWidget)
        intent.putParcelableArrayListExtra(Album.KEY_INPUT_CHECKED_LIST, mChecked)
        intent.putExtra(Album.KEY_INPUT_CURRENT_POSITION, mCurrentPosition)
        intent.putExtra(Album.KEY_INPUT_GALLERY_CHECKABLE, mCheckable)
        mContext.startActivity(intent)
    }
}
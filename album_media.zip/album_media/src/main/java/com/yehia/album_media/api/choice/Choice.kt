package com.yehia.album_media.api.choice

interface Choice<Multiple, Single> {
    /**
     * Multiple choice.
     */
    fun multipleChoice(): Multiple

    /**
     * Single choice.
     */
    fun singleChoice(): Single
}
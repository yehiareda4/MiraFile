package com.yehia.album_media.api

import android.content.Context
import android.content.Intent
import com.yehia.album_media.Album
import com.yehia.album_media.app.gallery.GalleryActivity

class GalleryWrapper(context: Context) :
    BasicGalleryWrapper<GalleryWrapper, String, String, String>(context) {
    override fun start() {
        GalleryActivity.sResult = mResult
        GalleryActivity.sCancel = mCancel
        GalleryActivity.sClick = mItemClick
        GalleryActivity.sLongClick = mItemLongClick
        val intent = Intent(mContext, GalleryActivity::class.java)
        intent.putExtra(Album.KEY_INPUT_WIDGET, mWidget)
        intent.putStringArrayListExtra(Album.KEY_INPUT_CHECKED_LIST, mChecked)
        intent.putExtra(Album.KEY_INPUT_CURRENT_POSITION, mCurrentPosition)
        intent.putExtra(Album.KEY_INPUT_GALLERY_CHECKABLE, mCheckable)
        mContext.startActivity(intent)
    }
}
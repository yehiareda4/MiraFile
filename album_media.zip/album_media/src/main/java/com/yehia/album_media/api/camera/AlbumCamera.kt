package com.yehia.album_media.api.camera

import android.content.Context
import com.yehia.album_media.api.ImageCameraWrapper
import com.yehia.album_media.api.VideoCameraWrapper

class AlbumCamera(private val mContext: Context) : Camera<ImageCameraWrapper, VideoCameraWrapper> {
    override fun image(): ImageCameraWrapper {
        return ImageCameraWrapper(mContext)
    }

    override fun video(): VideoCameraWrapper {
        return VideoCameraWrapper(mContext)
    }
}
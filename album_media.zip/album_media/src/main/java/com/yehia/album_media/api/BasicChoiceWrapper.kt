package com.yehia.album_media.api

import android.content.Context
import androidx.annotation.IntRange
import com.yehia.album_media.Filter

abstract class BasicChoiceWrapper<Returner : BasicChoiceWrapper<Returner, *, *, *>, Result, Cancel, Checked> internal constructor(
    context: Context
) : BasicAlbumWrapper<Returner, Result, Cancel, Checked>(context) {
    var mHasCamera = true
    var mColumnCount = 2
    lateinit var mSizeFilter: Filter<Long>
    lateinit var mMimeTypeFilter: Filter<String>
    var mFilterVisibility = true

    /**
     * Turn on the camera function.
     */
    fun camera(hasCamera: Boolean): Returner {
        mHasCamera = hasCamera
        return this as Returner
    }

    /**
     * Sets the number of columns for the page.
     *
     * @param count the number of columns.
     */
    fun columnCount(@IntRange(from = 2, to = 4) count: Int): Returner {
        mColumnCount = count
        return this as Returner
    }

    /**
     * Filter the file size.
     *
     * @param filter filter.
     */
    fun filterSize(filter: Filter<Long>): Returner {
        mSizeFilter = filter
        return this as Returner
    }

    /**
     * Filter the file extension.
     *
     * @param filter filter.
     */
    fun filterMimeType(filter: Filter<String>): Returner {
        mMimeTypeFilter = filter
        return this as Returner
    }

    /**
     * The visibility of the filtered file.
     *
     * @param visibility true is displayed, false is not displayed.
     */
    fun afterFilterVisibility(visibility: Boolean): Returner {
        mFilterVisibility = visibility
        return this as Returner
    }
}
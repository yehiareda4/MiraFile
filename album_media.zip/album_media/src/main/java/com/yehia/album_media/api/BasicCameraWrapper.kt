package com.yehia.album_media.api

import android.content.Context
import com.yehia.album_media.Action

abstract class BasicCameraWrapper<Returner : BasicCameraWrapper<Returner>>(var mContext: Context) {
    lateinit var mResult: Action<String>
    lateinit var mCancel: Action<String>
    var mFilePath: String = ""

    /**
     * Set the action when result.
     *
     * @param result action when producing result.
     */
    fun onResult(result: Action<String>): Returner {
        mResult = result
        return this as Returner
    }

    /**
     * Set the action when canceling.
     *
     * @param cancel action when canceled.
     */
    fun onCancel(cancel: Action<String>): Returner {
        mCancel = cancel
        return this as Returner
    }

    /**
     * Set the image storage path.
     *
     * @param filePath storage path.
     */
    fun filePath(filePath: String): Returner {
        mFilePath = filePath
        return this as Returner
    }

    /**
     * Start up.
     */
    abstract fun start()
}
package com.yehia.album_media.api

import android.content.Context
import androidx.annotation.IntRange
import com.yehia.album_media.ItemAction

abstract class BasicGalleryWrapper<Returner : BasicGalleryWrapper<Returner, *, *, *>, Result, Cancel, Checked>(
    context: Context
) : BasicAlbumWrapper<Returner, ArrayList<Result>, Cancel, ArrayList<Checked>>(context) {
    lateinit var mItemClick: ItemAction<Checked>
    lateinit var mItemLongClick: ItemAction<Checked>
    var mCurrentPosition = 0
    var mCheckable = false

    /**
     * Set the list has been selected.
     *
     * @param checked the data list.
     */
    fun checkedList(checked: ArrayList<Checked>): Returner {
        mChecked = checked
        return this as Returner
    }

    /**
     * When the preview item is clicked.
     *
     * @param click action.
     */
    fun itemClick(click: ItemAction<Checked>): Returner {
        mItemClick = click
        return this as Returner
    }

    /**
     * When the preview item is clicked long.
     *
     * @param longClick action.
     */
    fun itemLongClick(longClick: ItemAction<Checked>): Returner {
        mItemLongClick = longClick
        return this as Returner
    }

    /**
     * Set the show position of List.
     *
     * @param currentPosition the current position.
     */
    fun currentPosition(
        @IntRange(
            from = 0,
            to = Int.MAX_VALUE.toLong()
        ) currentPosition: Int
    ): Returner {
        mCurrentPosition = currentPosition
        return this as Returner
    }

    /**
     * The ability to select pictures.
     *
     * @param checkable checkBox is provided.
     */
    fun checkable(checkable: Boolean): Returner {
        mCheckable = checkable
        return this as Returner
    }
}
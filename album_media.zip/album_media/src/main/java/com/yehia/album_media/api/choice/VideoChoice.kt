package com.yehia.album_media.api.choice

import android.content.Context
import com.yehia.album_media.api.VideoMultipleWrapper
import com.yehia.album_media.api.VideoSingleWrapper

class VideoChoice(private val mContext: Context) :
    Choice<VideoMultipleWrapper, VideoSingleWrapper> {
    override fun multipleChoice(): VideoMultipleWrapper {
        return VideoMultipleWrapper(mContext)
    }

    override fun singleChoice(): VideoSingleWrapper {
        return VideoSingleWrapper(mContext)
    }
}
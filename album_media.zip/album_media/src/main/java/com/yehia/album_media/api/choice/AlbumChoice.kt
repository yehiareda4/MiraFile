package com.yehia.album_media.api.choice

import android.content.Context
import com.yehia.album_media.api.AlbumMultipleWrapper
import com.yehia.album_media.api.AlbumSingleWrapper

class AlbumChoice(private val mContext: Context) :
    Choice<AlbumMultipleWrapper, AlbumSingleWrapper> {
    override fun multipleChoice(): AlbumMultipleWrapper {
        return AlbumMultipleWrapper(mContext)
    }

    override fun singleChoice(): AlbumSingleWrapper {
        return AlbumSingleWrapper(mContext)
    }
}
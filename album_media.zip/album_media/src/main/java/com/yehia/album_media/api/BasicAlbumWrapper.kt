package com.yehia.album_media.api

import android.content.Context
import com.yehia.album_media.Action
import com.yehia.album_media.api.widget.Widget

abstract class BasicAlbumWrapper<Returner : BasicAlbumWrapper<Returner, *, *, *>, Result, Cancel, Checked> internal constructor(
    val mContext: Context
) {
    lateinit var mResult: Action<Result> 
    lateinit var mCancel: Action<Cancel>
    var mWidget: Widget
    var mChecked: Checked? = null

    /**
     * Set the action when result.
     *
     * @param result action when producing result.
     */
    fun onResult(result: Action<Result>): Returner {
        mResult = result
        return this as Returner
    }

    /**
     * Set the action when canceling.
     *
     * @param cancel action when canceled.
     */
    fun onCancel(cancel: Action<Cancel>): Returner {
        mCancel = cancel
        return this as Returner
    }

    /**
     * Set the widget property.
     *
     * @param widget the widget.
     */
    fun widget(widget: Widget): Returner {
        mWidget = widget
        return this as Returner
    }

    /**
     * Start up.
     */
    abstract fun start()

    init {
        mWidget = Widget.getDefaultWidget(mContext)
    }
}
package com.yehia.album_media.api.camera

interface Camera<Image, Video> {
    /**
     * Take picture.
     */
    fun image(): Image

    /**
     * Take video.
     */
    fun video(): Video
}
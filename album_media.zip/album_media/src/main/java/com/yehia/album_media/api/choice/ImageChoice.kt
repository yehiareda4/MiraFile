package com.yehia.album_media.api.choice

import android.content.Context
import com.yehia.album_media.api.ImageMultipleWrapper
import com.yehia.album_media.api.ImageSingleWrapper

class ImageChoice(private val mContext: Context) :
    Choice<ImageMultipleWrapper, ImageSingleWrapper> {
    override fun multipleChoice(): ImageMultipleWrapper {
        return ImageMultipleWrapper(mContext)
    }

    override fun singleChoice(): ImageSingleWrapper {
        return ImageSingleWrapper(mContext)
    }
}